<?php
// Include session and cookie handling script
include 'session.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Basic Navbar</title>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <link rel="stylesheet" href="./CSS/index.css" />
</head>

<body>
  <nav class="navbar">
    <div class="logo"><img src="./New folder/logo.png" alt="" /></div>
    <div class="nav-links">
      <a href="index.php">Home</a>
      <a href="about.php">About</a>
      <a href="./view_data.php">Dispaly</a>
      <a href="./insert.php">Register</a>
      <i class="fa-solid fa-bars"></i>
    </div>
  </nav>
  <div class="container">
    <div class="left">
      <p class="learning"><i>Learning</i></p>
      <h1>Welcome To Artificial Intelligence</h1>
      <p class="para">
        Artificial intelligence (AI) is rapidly transforming our world. It refers to the simulation of human intelligence in machines that are programmed to think and learn like humans. AI encompasses various subfields like machine learning and deep learning, enabling systems to analyze vast amounts of data and make intelligent decisions. From self-driving cars and medical diagnoses to personalized recommendations and language translation, AI is revolutionizing industries and our daily lives. While AI holds immense potential for progress, it also raises important ethical considerations and challenges that need careful attention.
      </p>
    </div>
    <div class="right">
      <img src="./New folder/avatar.png" alt="" />
    </div>
  </div>
  <!-- User Preferences Form -->
  <div class="user-form">
    <form method="POST" action="">
      <label for="username">Username:</label>
      <input type="text" name="username" id="username" value="<?php echo $_SESSION['username']; ?>" />

      <label for="preference">Preference:</label>
      <select name="preference" id="preference">
        <option value="dark_mode" <?php echo isset($_COOKIE['user_preference']) && $_COOKIE['user_preference'] == 'dark_mode' ? 'selected' : ''; ?>>Dark Mode</option>
        <option value="light_mode" <?php echo isset($_COOKIE['user_preference']) && $_COOKIE['user_preference'] == 'light_mode' ? 'selected' : ''; ?>>Light Mode</option>
      </select>

      <button type="submit">Save</button>
    </form>
  </div>
  <!-- Image grid section -->
  <div class="image-grid">
    <a href="./detail/quantum.html">
      <img src="./Images/quantum.jpg" alt="Image 1" />
    </a>
    
    <img src="./images/cyber.jpg" alt="Image 2" />
    <img src="./images/web.jpg" alt="Image 3" />
    <img src="./images/meta.jpg" alt="Image 4" />
    <img src="./images/app.jpg" alt="Image 5" />
    <img src="./images/Analisies.jpg" alt="Image 6" />
    <img src="./images/ai.jpg" alt="Image 7" />
    <img src="./images/5G.jpg" alt="Image 8" />
    <img src="./images/iot.jpg" alt="Image 9" />
    <img src="./images/medical.jpg" alt="Image 10" />
    <img src="./images/tech.jpg" alt="Image 11" />
    <img src="./images/robots.jpg" alt="Image 12" />
    <img src="./images/NLP.jpg" alt="Image 13" />
    <img src="./images/Neural.jpg" alt="Image 14" />
    <img src="./images/Analisies.jpg" alt="Image 15" />
    <img src="./images/CPU.jpg" alt="Image 16" />

  </div>

  <!-- Footer section -->
  <footer>
    <p>&copy; 2024 Your Website. All rights reserved.</p>
  </footer>
</body>

</html>