<?php
// Include your database connection file
include("db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape user inputs for security
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $age = mysqli_real_escape_string($conn, $_POST['age']);
    $field_of_study = mysqli_real_escape_string($conn, $_POST['field_of_study']);

    // Attempt to insert data
    $sql = "INSERT INTO ihtatable (first_name, last_name, age, field_of_study) VALUES ('$first_name', '$last_name', '$age', '$field_of_study')";
    if(mysqli_query($conn, $sql)){
        ?>
        <script>
            alert("Record inserted successfully");
        </script>
        <?php
    } else{
        ?>
        <script>
            alert("Error inserting record");
        </script>
        <?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Responsive Form</title>
        <style>
                * {
                        box-sizing: border-box;
                        margin: 0;
                        padding: 0;
                        font-family: Arial, sans-serif;
                }

                body {
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        background-color: #f4f4f4;
                }

                .container {
                        width: 100%;
                        max-width: 400px;
                        margin: 20px;
                        padding: 20px;
                        background-color: #fff;
                        border-radius: 8px;
                        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                }

                h2 {
                        margin-bottom: 20px;
                        text-align: center;
                        color: #333;
                }

                label {
                        display: block;
                        margin-bottom: 5px;
                        color: #555;
                }

                input {
                        width: 100%;
                        padding: 10px;
                        margin-bottom: 15px;
                        border: 1px solid #ddd;
                        border-radius: 4px;
                }

                button {
                        width: 100%;
                        padding: 10px;
                        background-color: #F77266;
                        border: none;
                        border-radius: 4px;
                        color: white;
                        font-size: 16px;
                        cursor: pointer;
                        margin-bottom: 10px;
                        transition: background-color 0.3s ease;
                }

                button:hover {
                        background-color: #0056b3;
                }

                input[type="button"] {
                        width: 100%;
                        padding: 10px;
                        background-color: #F77266;
                        border: none;
                        border-radius: 4px;
                        color: white;
                        font-size: 16px;
                        cursor: pointer;
                        margin-bottom: 10px;
                        transition: background-color 0.3s ease;
                }

                input[type="button"]:hover {
                        background-color: #0056b3;
                }

                @media (max-width: 600px) {
                        .container {
                                margin: 10px;
                                padding: 15px;
                        }

                        h2 {
                                font-size: 18px;
                        }

                        button {
                                font-size: 14px;
                        }
                }
        </style>
</head>
<body>
    <div class="container">
        <form action="" method="post" class="responsive-form">
            <h2>User Information</h2>
            <label for="first-name">First Name</label>
            <input type="text" id="first-name" name="first_name" required>

            <label for="last-name">Last Name</label>
            <input type="text" id="last-name" name="last_name" required>

            <label for="age">Age</label>
            <input type="number" id="age" name="age" required>

            <label for="field-of-study">Field of Study</label>
            <input type="text" id="field-of-study" name="field_of_study" required>

            <button type="submit">Submit</button>
                <a href="view_data.php"><input type="button" value="view_data"></a>
        </form>
    </div>
    
</body>
</html>
