<?php include ("db_connect.php");
$id = $_GET['id'];

$sql = "DELETE FROM ihtatable WHERE id=$id";
$result = $conn->query($sql);

if ($result) {
        ?>
        <script>
                alert("Record deleted successfully");
                window.location = "view_data.php";      
        </script>
        <?php
} else {
        ?>
        <script>
                alert("Error deleting record");
                window.location = "view_data.php";
        </script>
        <?php
}
?>