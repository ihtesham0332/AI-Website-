<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Me - Muhammad Ihtesham Khan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            padding: 20px;

            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        .profile-picture {
            text-align: center;
            margin-bottom: 20px;
            /* Background image for the picture */
            background-size: cover;
            /* Ensures the background image covers the entire area */
            background-position: center;
            /* Centers the background image */

        }
        .profile-picture img {
            border-radius: 50%; /* Circular image */
            width: 250px;
            height: 250px;
            object-fit: cover;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Shadow around the image */
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1vw 3vw;
            height: 5vh;
            border-bottom: 2px solid #f77266;
        }

        .navbar .logo img {
            height: 3vw;
            margin-top: 0.5vw;
            border-radius: 50%;
        }

        .navbar a,
        i {
            text-decoration: none;
            padding: 0.5rem 1rem;
        }

        .navbar i {
            display: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .navbar .logo {
            font-size: 1.5rem;
            font-weight: bold;
            border-radius: 50%;
        }
        .navbar img {
                height: 4.5vw;
                border: #0077b5;
            }

        .navbar .nav-links {
            display: flex;
        }

        /* nave header is full */
        @media (max-width: 768px) {
            body {
                overflow: hidden;
            }

            .navbar img {
                height: 4.5vw;
            }

            .navbar .nav-links a {
                display: none;
            }

            .navbar i {
                display: inline;
                font-size: 2.5vw;
            }

            .profile-picture img {
                border-radius: 50%;
                width: 250px;
                height: 250px;
                object-fit: cover;
                margin-bottom: 20px;


            }
        }

        .content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            text-align: center;
        }

        .content p {
            font-size: 18px;
            line-height: 1.6;
            text-align: justify;
        }

        .skills,
        .competences,
        .education,
        .hobbies,
        .languages {
            width: 100%;
            margin-bottom: 20px;
        }

        .skills ul,
        .competences ul,
        .education ul,
        .hobbies ul,
        .languages ul {
            list-style: none;
            padding: 0;
        }

        .skills ul li,
        .competences ul li,
        .education ul li,
        .hobbies ul li,
        .languages ul li {
            background-color: #ecf0f1;
            margin: 5px 0;
            padding: 10px;
            border-radius: 5px;
        }

        .social-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .social-buttons a {
            text-decoration: none;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            font-weight: bold;
        }

        .social-buttons .linkedin {
            background-color: #0077b5;
        }

        .social-buttons .facebook {
            background-color: #3b5998;
        }

        .social-buttons .twitter {
            background-color: #1da1f2;
        }

        .social-buttons .github {
            background-color: #333;
        }

        footer {
            text-align: center;
            padding: 20px;
            background-color: #2c3e50;
            color: white;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-top: 40px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }

            .content p {
                font-size: 16px;
            }

            .skills ul li,
            .competences ul li,
            .education ul li,
            .hobbies ul li,
            .languages ul li {
                padding: 8px;
                font-size: 14px;
            }

            .social-buttons a {
                padding: 8px 12px;
            }
        }

        @media (max-width: 480px) {
            h1 {
                font-size: 24px;
            }

            .content p {
                font-size: 14px;
            }

            .skills ul li,
            .competences ul li,
            .education ul li,
            .hobbies ul li,
            .languages ul li {
                padding: 6px;
                font-size: 12px;
            }

            .social-buttons a {
                padding: 6px 10px;
                font-size: 14px;
            }

            footer p {
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="profile-picture">
            <nav class="navbar">
                <div class="logo"><img src="./New folder/logo.png" alt="" /></div>
                <div class="nav-links">
                    <a href="index.php">Home</a>
                    <a href="about.php">About</a>
                    <a href="./view_data.php">Dispaly</a>
                    <a href="./insert.php">Register</a>
                    <i class="fa-solid fa-bars"></i>
                </div>
            </nav>
            <h1>About Me</h1>
            <img src="1.jpg" alt="Muhammad Ihtesham Khan" />
            <h2>Muhammad Ihtesham Khan</h2>
        </div>
        <div class="content">
            <!-- aline this paragraph to the center of the picture -->
            <p>I am a software engineer with a passion for AI and machine learning. I have worked on various projects using Python and have a strong foundation in programming languages. My goal is to contribute to the field and make a positive impact on society.</p>

            <div class="skills">
                <h2>Skills</h2>
                <ul>
                    <li>Software Development</li>
                    <li>Machine Learning</li>
                    <li>Artificial Intelligence</li>
                    <li>Web Development</li>
                </ul>
            </div>

            <div class="competences">
                <h2>Competences</h2>
                <ul>
                    <li>Problem Solving</li>
                    <li>Team Collaboration</li>
                    <li>Project Management</li>
                </ul>
            </div>

            <div class="education">
                <h2>Education</h2>
                <ul>
                    <li>Bachelor of Science in Computer Science</li>
                </ul>
            </div>

            <div class="hobbies">
                <h2>Hobbies</h2>
                <ul>
                    <li>Reading</li>
                    <li>Programming</li>
                    <li>Gaming</li>
                </ul>
            </div>

            <div class="languages">
                <h2>Languages</h2>
                <ul>
                    <li>English</li>
                    <li>Urdu</li>
                </ul>
            </div>

            <div class="social-buttons">
                <a href="https://www.linkedin.com/in/muhammad-ihtesham-khan-0332i/" class="linkedin">LinkedIn</a>
                <a href="https://www.facebook.com/ihtesham.khan.5030927" class="facebook">Facebook</a>
                <a href="https://twitter.com/" class="twitter">X</a>
                <a href="https://github.com/ihtesham0332" class="github">GitHub</a>
            </div>
        </div>
    </div>
    <footer>
        <p>&copy; 2024 Muhammad Ihtesham Khan. All Rights Reserved.</p>
    </footer>
</body>

</html>