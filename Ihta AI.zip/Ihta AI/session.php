<?php
// Start the session
session_start();

// Check if a session variable is set
if (!isset($_SESSION['username'])) {
    // Set a session variable
    $_SESSION['username'] = 'Guest';
}

// Check if a cookie is set
if (!isset($_COOKIE['user_preference'])) {
    // Set a cookie that expires in 30 days
    setcookie('user_preference', 'dark_mode', time() + (86400), "/");
}

// Example: Changing session and cookie values based on user interaction
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['username'])) {
        $_SESSION['username'] = htmlspecialchars($_POST['username']);
    }
    if (isset($_POST['preference'])) {
        setcookie('user_preference', htmlspecialchars($_POST['preference']), time() + (86400 * 30), "/");
    }
}
?>
