<?php
include("db_connect.php");

$sql = "SELECT * FROM ihtatable"; // Replace 'your_table_name' with your actual table name
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Professional Table</title>
        <style>
                * {
                        box-sizing: border-box;
                        margin: 0;
                        padding: 0;
                }

                .navbar {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        padding: 2vw 3vw;
                        height: 5vh;
                        border-bottom: 2px solid #f77266;
                }

                .navbar .logo img {
                        height: 3vw;
                        margin-top: 0.5vw;
                        border-radius: 50%;
                }

                .navbar a,
                i {
                        text-decoration: none;
                        padding: 0.5rem 1rem;
                }

                .navbar i {
                        display: none;
                }

                .navbar a:hover {
                        background-color: #ddd;
                        color: black;
                }

                .navbar .logo {
                        font-size: 1.5rem;
                        font-weight: bold;
                        border-radius: 50%;
                }

                .navbar img {
                        height: 4.5vw;
                        border: #0077b5;
                }

                .navbar .nav-links {
                        display: flex;
                }

                /* nave header is full */
                @media (max-width: 768px) {
                        body {
                                overflow: hidden;
                        }

                        .navbar img {
                                height: 4.5vw;
                        }

                        .navbar .nav-links a {
                                display: none;
                        }

                        .navbar i {
                                display: inline;
                                font-size: 2.5vw;
                        }

                        body {
                                font-family: Arial, sans-serif;
                        }

                        .container {
                                max-width: 800px;
                                margin: 20px auto;
                        }
                }

                h2 {
                        text-align: center;
                        margin-bottom: 20px;
                        color: white;
                        background-color: #F77266;
                        padding: 10px;
                        border-radius: 8px;
                        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                        font-size: 24px;
                        font-weight: bold;
                        text-transform: uppercase;
                        letter-spacing: 2px;
                }

                table {
                        width: 100%;
                        border-collapse: collapse;
                }

                table th,
                table td {
                        border: 1px solid #ddd;
                        padding: 8px;
                        text-align: left;
                        text-align: center;
                }

                table th {
                        background-color: #f2f2f2;
                }

                table tbody tr:nth-child(even) {
                        background-color: #f9f9f9;
                }

                table tbody tr:hover {
                        background-color: #f2f2f2;
                }

                .action-btns button {
                        padding: 5px 10px;
                        margin-right: 5px;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                }

                .update-btn {
                        background-color: #4CAF50;
                        color: white;
                        padding: 5px 10px;
                        cursor: pointer;
                        border-radius: 8px;
                        border: none;
                        text-decoration: none;

                }

                .delete-btn {
                        background-color: #f44336;
                        color: white;
                        padding: 5px 10px;
                        cursor: pointer;
                        border-radius: 8px;
                        border: none;
                        text-decoration: none;
                }

                .btn_back input {
                        text-align: center;
                        padding: 5px 10px;
                        cursor: pointer;
                        border-radius: 8px;
                        border: none;
                        background-color: #F77266;
                        color: white;
                        font-size: 16px;
                        margin-top: 10px;
                }
        </style>
</head>

<body>
        <div class="container">
                <nav class="navbar">
                        <div class="logo"><img src="./New folder/logo.png" alt="" /></div>
                        <div class="nav-links">
                                <a href="index.php">Home</a>
                                <a href="about.php">About</a>
                                <a href="./view_data.php">Dispaly</a>
                                <a href="./insert.php">Register</a>
                                <i class="fa-solid fa-bars"></i>
                        </div>
                </nav>
                <h2>DISPLAY DATA</h2>
                <table>
                        <thead>
                                <tr>
                                        <th>ID</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Age</th>
                                        <th>Field of Study</th>
                                        <th>Action</th>
                                </tr>
                        </thead>
                        <tbody>
                                <?php
                                if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["id"] . "</td>";
                                                echo "<td>" . $row["First_Name"] . "</td>";
                                                echo "<td>" . $row["Last_Name"] . "</td>";
                                                echo "<td>" . $row["age"] . "</td>";
                                                echo "<td>" . $row["Field_of_Study"] . "</td>";
                                                echo "<td> 
            <a class='update-btn' href='update_data.php?id=" . $row["id"] . "'>Update</a>

            <a onclick='return confirm(\"Are you sure you want to delete this record?\")' class='delete-btn' href='delete_data.php?id=" . $row["id"] . "'>Delete</a>
        </td>";
                                                echo "</tr>";
                                        }
                                } else {
                                        echo "<tr><td colspan='6'>No Record Found</td></tr>";
                                }
                                ?>

                        </tbody>
                </table>
                <a class="btn_back" href="index.php"><input type="button" value="Back"></a>
                <a class="btn_back" href="insert.php"><input type="button" value="Insert New Data"></a>
        </div>
</body>

</html>

<?php
$conn->close();
?>