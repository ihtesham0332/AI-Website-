<?php
include 'db_connect.php';  

$id=$_GET['id'];

$sql = "SELECT * FROM ihtatable WHERE id = $id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $age = $_POST['age'];
    $field_of_study = $_POST['field_of_study'];

    $sql = "UPDATE ihtatable SET first_name = '$first_name', last_name = '$last_name', age = '$age', field_of_study = '$field_of_study' WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Form</title>
    
    <style>
                * {
                        box-sizing: border-box;
                        margin: 0;
                        padding: 0;
                        font-family: Arial, sans-serif;
                }

                body {
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        background-color: #f4f4f4;
                }

                .container {
                        width: 100%;
                        max-width: 400px;
                        margin: 20px;
                        padding: 20px;
                        background-color: #fff;
                        border-radius: 8px;
                        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                }

                h2 {
                        margin-bottom: 20px;
                        text-align: center;
                        color: #333;
                }

                label {
                        display: block;
                        margin-bottom: 5px;
                        color: #555;
                }

                input {
                        width: 100%;
                        padding: 10px;
                        margin-bottom: 15px;
                        border: 1px solid #ddd;
                        border-radius: 4px;
                }

                button {
                        width: 100%;
                        padding: 10px;
                        background-color: #F77266;
                        border: none;
                        border-radius: 4px;
                        color: white;
                        font-size: 16px;
                        cursor: pointer;
                        margin-bottom: 10px;
                        transition: background-color 0.3s ease;
                }

                button:hover {
                        background-color: #0056b3;
                }

                input[type="button"] {
                        width: 100%;
                        padding: 10px;
                        background-color: #F77266;
                        border: none;
                        border-radius: 4px;
                        color: white;
                        font-size: 16px;
                        cursor: pointer;
                        margin-bottom: 10px;
                        transition: background-color 0.3s ease;
                }

                input[type="button"]:hover {
                        background-color: #0056b3;
                }

                @media (max-width: 600px) {
                        .container {
                                margin: 10px;
                                padding: 15px;
                        }

                        h2 {
                                font-size: 18px;
                        }

                        button {
                                font-size: 14px;
                        }
                }
        </style>
</head>
<body>
    <div class="container">
        <form method="POST" class="responsive-form">
            <h2>User Information</h2>
            <label for="first-name">First Name</label>
            <input value="<?php echo isset($row['first_name']) ? htmlspecialchars($row['first_name']) : ''; ?>" type="text" name="first_name" required>

            <label for="last-name">Last Name</label>
            <input value="<?php echo isset($row['last_name']) ? htmlspecialchars($row['last_name']) : ''; ?>" type="text" name="last_name" required>

            <label for="age">Age</label>
            <input value="<?php echo isset($row['age']) ? htmlspecialchars($row['age']) : ''; ?>" type="number" name="age" required>

            <label for="field-of-study">Field of Study</label>
            <input value="<?php echo isset($row['field_of_study']) ? htmlspecialchars($row['field_of_study']) : ''; ?>" type="text" name="field_of_study" required>

            <button type="submit">Update</button>
            <a href="view_data.php"><input type="button" value="view_data"></a>
        </form>
    </div>
</body>
</html>